import streamlit as st
from PyPDF2 import PdfReader
from langdetect import detect
from gtts import gTTS
import tempfile
import os

# -------------------- Language Support -------------------- #
supported_languages = {
    "English": "en",
    "Tamil": "ta",
    "Hindi": "hi",
    "Telugu": "te",
    "Kannada": "kn",
    "Malayalam": "ml",
    "Bengali": "bn",
    "Marathi": "mr",
    "French": "fr",
    "Spanish": "es",
    "German": "de",
    "Chinese (Simplified)": "zh-CN",
    "Japanese": "ja",
    "Arabic": "ar"
}

# -------------------- Helper Functions -------------------- #
def extract_text_from_pdf(uploaded_file, start_page=None, end_page=None):
    reader = PdfReader(uploaded_file)
    num_pages = len(reader.pages)
    start_page = max(0, start_page if start_page is not None else 0)
    end_page = min(end_page if end_page is not None else num_pages - 1, num_pages - 1)
    
    text = ""
    for i in range(start_page, end_page + 1):
        page_text = reader.pages[i].extract_text()
        if page_text:
            text += page_text + "\n"
    return text.strip(), num_pages

def detect_language(text):
    try:
        return detect(text)
    except:
        return "unknown"

def convert_text_to_audio(text, lang, slow=False):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp_file:
        tts = gTTS(text=text, lang=lang, slow=slow)
        tts.save(tmp_file.name)
        return tmp_file.name

# -------------------- Streamlit UI -------------------- #
st.set_page_config(page_title="PDF & Text to Audio", layout="centered")
st.title("🔊 PDF & Text to Audio Converter")

tab1, tab2 = st.tabs(["📄 PDF to Speech", "✍️ Text to Speech"])

# -------------------- Tab 1: PDF to Speech -------------------- #
with tab1:
    uploaded_pdf = st.file_uploader("Upload PDF", type=["pdf"])

    if uploaded_pdf is not None:
        text, total_pages = extract_text_from_pdf(uploaded_pdf)
        if text:
            st.success(f"Extracted {total_pages} pages.")
            col1, col2 = st.columns(2)
            start_page = col1.number_input("Start Page", 0, total_pages - 1, 0)
            end_page = col2.number_input("End Page", 0, total_pages - 1, total_pages - 1)
            text, _ = extract_text_from_pdf(uploaded_pdf, int(start_page), int(end_page))

            mode = st.radio("Language Mode", ["Auto Detect", "Manual Select"])
            if mode == "Auto Detect":
                lang = detect_language(text)
                lang_name = next((k for k, v in supported_languages.items() if v == lang), "Unsupported")
            else:
                lang_name = st.selectbox("Select Language", list(supported_languages.keys()))
                lang = supported_languages[lang_name]

            st.info(f"Language: **{lang_name}**")
            is_slow = st.radio("Speed", ["Normal", "Slow"]) == "Slow"

            st.subheader("Extracted Text")
            st.text_area("Preview", text[:3000], height=200)

            st.download_button("Download Extracted Text", text, file_name="text.txt")

            if lang in supported_languages.values():
                if st.button("🔊 Convert to Audio"):
                    with st.spinner("Creating audio..."):
                        path = convert_text_to_audio(text, lang, slow=is_slow)
                        with open(path, "rb") as f:
                            st.audio(f.read(), format="audio/mp3")
                            st.download_button("Download MP3", f, file_name="output.mp3")
                        os.remove(path)
            else:
                st.error("Unsupported language for audio.")
        else:
            st.warning("No extractable text found.")
    else:
        st.info("Upload a PDF to start.")

# -------------------- Tab 2: Text to Speech -------------------- #
with tab2:
    user_text = st.text_area("Enter text to convert to speech", height=200)

    if user_text.strip():
        lang_name = st.selectbox("Select Language", list(supported_languages.keys()))
        lang = supported_languages[lang_name]
        is_slow = st.radio("Speech Speed", ["Normal", "Slow"], horizontal=True) == "Slow"

        if st.button("🔊 Convert Text to Speech"):
            with st.spinner("Generating speech..."):
                path = convert_text_to_audio(user_text, lang, slow=is_slow)
                with open(path, "rb") as f:
                    st.audio(f.read(), format="audio/mp3")
                    st.download_button("Download MP3", f, file_name="text_speech.mp3")
                os.remove(path)
    else:
        st.info("Please enter text to convert.")
