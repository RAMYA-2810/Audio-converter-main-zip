import streamlit as st
from PyPDF2 import PdfReader
from langdetect import detect
from gtts import gTTS
import tempfile
import os

# -------------------- Helper Functions -------------------- #
def extract_text_from_pdf(uploaded_file):
    reader = PdfReader(uploaded_file)
    text = ""
    for page in reader.pages:
        page_text = page.extract_text()
        if page_text:
            text += page_text
    return text.strip()

def detect_language(text):
    try:
        lang = detect(text)
        return lang
    except:
        return "unknown"

def convert_text_to_audio(text, lang):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp_file:
        tts = gTTS(text=text, lang=lang)
        tts.save(tmp_file.name)
        return tmp_file.name

# -------------------- Streamlit UI -------------------- #
st.set_page_config(page_title="PDF to Audio Converter", layout="centered")

st.title("📘 PDF to Audio Converter (Tamil & English)")
st.markdown("Upload a PDF file, and this app will read it aloud in Tamil or English.")

uploaded_pdf = st.file_uploader("📄 Upload your PDF file", type=["pdf"])

if uploaded_pdf is not None:
    with st.spinner("Extracting text from PDF..."):
        text = extract_text_from_pdf(uploaded_pdf)

    if text:
        st.subheader("🔍 Text Preview")
        st.text_area("Extracted Text", text[:3000], height=200)

        lang = detect_language(text)
        lang_display = "Tamil" if lang == "ta" else "English" if lang == "en" else "Unknown"
        st.info(f"Detected Language: **{lang_display}**")

        if lang in ["en", "ta"]:
            if st.button("🔊 Convert to Audio"):
                with st.spinner("Generating audio..."):
                    audio_path = convert_text_to_audio(text, lang)
                    with open(audio_path, "rb") as audio_file:
                        st.audio(audio_file.read(), format="audio/mp3")
                        st.download_button("⬇️ Download MP3", audio_file, file_name="output.mp3")
                    os.remove(audio_path)
        else:
            st.error("❌ Unsupported language detected. Only Tamil and English are supported.")
    else:
        st.error("❌ No text found in the uploaded PDF.")
else:
    st.info("Please upload a PDF to begin.")
